<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    protected $fillable = [
        // Add fillable fields here when the migration is updated
    ];

    // Add relationships here when the migration is updated
}